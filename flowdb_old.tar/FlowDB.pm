#!perl
use strict;

package FlowDB;
use base qw(DBIx::Class::Schema);
use Carp qw(carp cloak);

sub import {
    my ($class,$db_ref,$file) = @_;
    $$db_ref = $class->connect(
      'dbi:SQLite:dbname='.($file||"flow.db"),
      "", "", {
        on_connect_call => 'use_foreign_keys'
      },
    );
}

__PACKAGE__->load_classes(qw/Task Step PreReq PriorStep/);

sub create_update_task {
    use Date::Format::SQLite qw(parse_datetime);
    my ($self,$task_info,@steps) = @_;

    my $mode = delete $task_info->{mode} || "create_or_update";

    my $task_dependences = delete $task_info->{dependences};

    $_ = parse_datetime($_) for $task_info->{ultimatum};
    delete $task_info->{entrydate};

    my $task = $self->resultset("Task")->$mode($task_info);

    my %existing_steps = map { $_ => 1 } $task->steps->get_column('ID')->all;

    for my $step (@steps) {
        
        my $id = $step->{id};
        my $mode = !defined($existing_step{$id}) ? 'create'
                 : $existing_step{$id}           ? 'update'
                 : (warn('Multiple definition of step ', $task->ID, '.', $id,
                        ' -- ignoring all but the first'),next)
                 ;

        my $dependences = delete $step->{dependences};
        $step = $db->resultset("Step")->$mode($step);

        my %existing_deps = map {
            my $id = sprintf '%s.%s',
                       $_->task->ID eq $task->ID ? '' : $task->ID,
                       $_->ID;
            $id => 1;
        } $step->prior_steps;

        for my $dep (@$dependences) {
            delete $existing_deps{$_} or next;
            $self->step_dependsOn_another($step,$dep);
        }

        $self->delete_dependence_of_step($step,$_) for keys %existing_deps;

        $existing_steps{$step->ID} = 0;

    }

    my $prereq_rs = $self->resultset("PreReq");
    $prereq_rs->create_or_update($_) for @$task_dependences;

    $self->delete_task_steps(
        map  { $task->steps->find({ ID => $_ }) }
        grep { !$existing_steps{$_} } keys $existing_steps
    );

}
sub step_dependsOn_another {
    use List::Util qw(first reduce);
    my ($self,$step,$another) = @_;

    $self->find_step($_) for $step, $another;

    die "Step ", $step->ROWID, "must not depend on itself (indirectly neither)" 
        if first { $_->ROWID eq $step->ROWID } $another->with_prior_steps;

    $self->resultset("PreReq")->create({
        any_task_step => $another->ID,
        required_for => $another->task->ID,
        weight => $another->ID
            ? $another->weight
            : reduce { $a + $b } 0,
              map { $_->weight } $another->task->all_steps
            ,
        description => $another->description
    });

    $step->before->create({ prior => $another });

}

sub delete_dependence_of_step {
    my ($self,$step,$another) = @_;
    $self->find_step($_) for $step, $another;
    $step->deps->search({ prior => $another->ID })->delete;

    my $dependences_still_exist = $another->prior->search({
        before => { -in => [$step->task->steps->get_column('ROWID')->all] }
    }) > 0;

    if ( !$dependences_still_exist ) {
        $self->resultset("PreReq")->find({
            any_task_step => $another->ID,
            required_for => $step->task->ID,
        })->delete;
    }
}

sub find_step {
    my ($self) = @_;
    return $_[1] if UNIVERSAL::isa($_[1], "FlowDB::Step");
    my ($task_id, $step_id) = $_[1] =~ m{ \A (\w+) (?:\.(\w+))? \z }xms;
    cloak "Invalid or incomplete step id: $_[1]" if !$task_id;
    $step_id ||= "";
    $_[1] = $self->resultset("Step")->find({ task => $task_id, ID => $step_id })
        or cloak "No step $_[1] found";
}

1;


