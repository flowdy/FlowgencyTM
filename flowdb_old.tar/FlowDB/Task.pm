#!perl
use strict;

package FlowDB::Task;
use base qw/DBIx::Class::Core/;
use Carp qw/carp cloak/;

__PACKAGE__->load_components(qw/InflateColumn::DateTime/);
__PACKAGE__->table('tasks');
__PACKAGE__->add_columns(qw/ID title priority description/),
__PACKAGE__->add_columns(
  entrydate => { data_type => 'datetime' },
  ultimatum => { data_type => 'datetime' },
);
__PACKAGE__->set_primary_key('ID');

__PACKAGE__->has_many(
   'steps' => 'FlowDB::Step',
   { 'foreign.task' => 'self.ID' }
);
__PACKAGE__->belongs_to(
   'defstep' => 'FlowDB::Step',
   { 'foreign.ID' => 'self.defstep' }
);

__PACKAGE__->has_many(
   'prerequisites' => 'FlowDB::PreReq',
   { 'foreign.required_for' => 'self.ID' }
);

sub all_steps {
    my $task_dep = {};
    return $task_dep, map { $_->after_prior_steps($task_dep) }
           shift->steps->all;
}

sub update_progress {
    my ($self) = @_;
    my ($done,$shares);

    my ($task_dep, @steps) = $self->all_steps;
    for my $s ( @steps ) {
        my $weight;
        if ( $s->task->ID ne $self->ID ) {
            my $t_dep = delete($task_dep->{$s->ID}) || next;
            my $s_dep = $task_dep->{$s->ID}->prerequisites->find(
                { task_step_id => $s->ID }
            );
            $weight = $s_dep->weight || $s->weight;
        }
        else { $weight = $s->weight }
        $done   += $s->done ? $weight : 0;
        $shares += $weight;
    }

    $shares ||= 1;
    $self->update({ done => $done, shares => $shares || 1 });

}

sub spread_progress_change {
    my ($self,@updated_steps) = (@_);

    $self->update_progress;

    my %tasks;
    my @steps = map {
        if ( !ref $_ ) { $_ = $self->steps->find({ ID => $_ });
              || cloak "No step of name $_";
        }
        else { cloak "Not one of my steps: ".$_->ID
              if $_->task_id ne $task->ID;
        }
        $_->and_dependent_steps(\%tasks);
    } @updated_steps;

    for my $step ( @steps )  {
        my $task = $step->task;
        my $step_dep = delete($tasks{$task->ID}) || next;
        $task->update_progress
            #if $task->prerequisites->search({
            #    required_for => { -in => $step_dep },
            #    weight       => undef,
            #})
            ;
    }

}

sub calc_rank {
    my ($self) = @_;

    my $progress = $self->done / $self->shares;

    my $elapsed = time - $self->entrydate->epoch;
    my $total_time = $self->ultimatum->epoch - $self->entrydate->epoch;

    my $duration = $elapsed / $total_time;

    return $progress,
         1 / (1-$duration)           # Umso höher, je weniger Zeit bleibt
         * $self->priority           # p = 1 hoch, 2 mittel, 3 niedrig >> 4-p
         * 10**($duration-$progress) # je weiter $duration $progress davonläuft,
         ;                           # umso höher, bzw. umgekehrt niedriger <1 
          
}

sub mark_as_done {
    my ($self,$id) = @_;
    my ($step,@all_steps) = $self->steps->find({ID => $id})->after_prior_steps;
    my $priors_done = 0;
    for my $s (@all_steps) {

        ->done(1);
    $self->spread_progress_update($id);
}

sub delete_steps {
    my ($self, @steps) = @_;
    $_->weight(0) for @steps;
    $self->spread_progress_change(@steps);
    ($_->ID eq '' ? $_->task : $_)->delete for @steps;
}

1;
