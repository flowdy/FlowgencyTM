#!perl
use strict;

package FlowDB::Step;
use base qw/DBIx::Class::Core/;
use Carp qw/carp croak/;

__PACKAGE__->table('steps');
__PACKAGE__->add_columns(qw/ROWID task ID title weight description seq_nr done/);
__PACKAGE__->set_primary_key('ROWID');
__PACKAGE__->belongs_to('task' => 'FlowDB::Task', { 'foreign.ID' => 'self.task' });
__PACKAGE__->has_many('deps' => 'FlowDB::PriorStep', { 'foreign.before' => 'self.ROWID' });
__PACKAGE__->many_to_many('prior_steps' => 'deps', 'prior');

__PACKAGE__->has_many('prior' => 'FlowDB::PriorStep', { 'foreign.prior' => 'self.ROWID' });
__PACKAGE__->many_to_many('required_for_steps' => 'prior', 'before');

sub after_prior_steps {
    my ($self,$task_dep) = @_;
    $task_dep ||= {};
    return (map { my $step = $_;
              $step->after_prior_steps($task_dep);
              $task_dep->{$step->ROWID} = $self->task;
              } $self->prior_steps
           ),
           $self;
}

sub and_dependent_steps {
    my ($self, $step_dep) = @_;
    $step_dep ||= {};
    return $self, map { my $step = $_;
       push @{$step_dep{$step->task->ID}}, $self;
       $_->and_dependent_steps($step_dep);
    } $self->required_for_steps;
}

1;

