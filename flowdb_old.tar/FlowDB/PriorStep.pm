#!perl
use strict;

package FlowDB::PriorStep;
use base qw/DBIx::Class::Core/;

__PACKAGE__->table('step4step');
__PACKAGE__->add_columns(qw/prior before/);
__PACKAGE__->belongs_to('prior' => "FlowDB::Step", { 'foreign.ROWID' => 'self.prior' });
__PACKAGE__->belongs_to('required_for' => "FlowDB::Step", { 'foreign.ROWID' => 'self.before' });

1;
