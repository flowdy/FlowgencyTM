#!perl
use strict;

package FlowDB::PreReq;
use base qw/DBIx::Class::Core/;

__PACKAGE__->table('preqs');
__PACKAGE__->add_columns(qw/ROWID required_for weight description/);
__PACKAGE__->add_column('any_task_step' => { accessor => "task_step_id" });
__PACKAGE__->set_primary_key('ROWID');
__PACKAGE__->belongs_to('task_step' => 'FlowDB::Step', { 'foreign.ROWID' => 'self.any_task_step' });


